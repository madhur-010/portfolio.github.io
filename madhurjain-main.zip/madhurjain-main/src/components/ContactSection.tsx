import { Mail, ArrowRight } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contact" className="px-6 md:px-16 lg:px-24 py-24 bg-foreground text-primary-foreground">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        <h2 className="text-4xl md:text-6xl font-display font-black uppercase leading-[0.95] tracking-tight">
          Let's Work
          <br />
          <span className="italic font-normal">Together</span>
        </h2>
        <p className="font-body text-primary-foreground/70 text-base leading-relaxed">
          I'm always open to exploring new opportunities, collaborations, and interesting projects. Feel free to reach out!
        </p>
        <a
          href="mailto:jainmadhur1234@gmail.com"
          className="inline-flex items-center gap-3 bg-primary-foreground text-foreground px-8 py-4 rounded-full font-body font-semibold text-sm hover:opacity-90 transition-opacity"
        >
          <Mail size={18} />
          jainmadhur1234@gmail.com
          <ArrowRight size={16} />
        </a>
      </div>
      <div className="mt-20 pt-8 border-t border-primary-foreground/20 flex flex-col md:flex-row justify-between items-center gap-4">
        <span className="font-body text-primary-foreground/50 text-sm">© 2025 Madhur Jain. All rights reserved.</span>
        <div className="flex gap-6">
          <a href="https://github.com/" target="_blank" rel="noopener noreferrer" className="font-body text-primary-foreground/50 text-sm hover:text-primary-foreground transition-colors">GitHub</a>
          <a href="mailto:jainmadhur1234@gmail.com" className="font-body text-primary-foreground/50 text-sm hover:text-primary-foreground transition-colors">Email</a>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
