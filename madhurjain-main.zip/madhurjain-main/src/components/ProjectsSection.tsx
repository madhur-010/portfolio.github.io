import { ArrowRight } from "lucide-react";

const projects = [
  {
    title: "Weather Data Analysis",
    description: "Analyzed weather datasets to identify trends and patterns using data analysis techniques.",
    tags: ["Data Analysis", "Python", "Visualization"],
  },
  {
    title: "Freehand Drawing App",
    description: "Built a drawing app allowing users to sketch freely with interactive controls and a clean UI.",
    tags: ["JavaScript", "Canvas API", "UI/UX"],
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="px-6 md:px-16 lg:px-24 py-24">
      <h2 className="text-4xl md:text-6xl font-display font-black uppercase leading-[0.95] tracking-tight mb-4">
        A Streamlined
        <br />
        Process for
        <br />
        <span className="italic font-normal">Exceptional Work</span>
      </h2>
      <p className="font-body text-muted-foreground max-w-lg mb-16">
        Projects that showcase my problem-solving abilities and passion for building real-world applications.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {projects.map((project, i) => (
          <div
            key={project.title}
            className="group bg-card border border-border rounded-2xl p-8 hover:border-foreground/30 transition-colors"
          >
            <span className="font-display text-6xl font-black text-border group-hover:text-accent transition-colors">
              0{i + 1}
            </span>
            <h3 className="font-display font-bold text-xl mt-4 mb-3">{project.title}</h3>
            <p className="font-body text-muted-foreground text-sm leading-relaxed mb-6">
              {project.description}
            </p>
            <div className="flex flex-wrap gap-2">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="font-body text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProjectsSection;
