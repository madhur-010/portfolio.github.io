import heroImg from "@/assets/hero-portrait.jpg";
import { ArrowRight } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="min-h-screen flex flex-col justify-center px-6 md:px-16 lg:px-24 py-20">
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-16 lg:px-24 py-6 bg-background/80 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-foreground" />
          <span className="font-body font-bold text-sm tracking-widest uppercase">Madhur</span>
        </div>
        <a
          href="#contact"
          className="bg-foreground text-primary-foreground px-5 py-2 rounded-full text-sm font-body font-semibold hover:opacity-90 transition-opacity flex items-center gap-2"
        >
          Contact <ArrowRight size={14} />
        </a>
      </nav>

      <div className="grid md:grid-cols-2 gap-12 items-center mt-16">
        <div className="space-y-6">
          <p className="font-body text-muted-foreground text-lg">Hey, I'm Madhur Jain</p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-black uppercase leading-[0.9] tracking-tight">
            A CS
            <br />
            <span className="italic font-normal">&amp; Tech</span>
            <br />
            Student
          </h1>
          <p className="font-body text-muted-foreground max-w-md text-base leading-relaxed">
            A passionate Computer Science student building impactful digital experiences through code, design, and problem-solving.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-3 bg-foreground text-primary-foreground px-6 py-3 rounded-full text-sm font-body font-semibold hover:opacity-90 transition-opacity"
          >
            Contact Me
            <span className="w-8 h-8 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <ArrowRight size={16} />
            </span>
          </a>
        </div>

        <div className="flex justify-center md:justify-end">
          <div className="w-72 h-80 md:w-80 md:h-96 rounded-[2rem] overflow-hidden border-4 border-secondary">
            <img
              src={heroImg}
              alt="Madhur Jain"
              className="w-full h-full object-cover"
              width={640}
              height={800}
            />
          </div>
        </div>
      </div>

      {/* Feature strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 border-t border-border pt-10">
        {[
          { title: "Problem Solver", desc: "Analytical thinking and debugging expertise." },
          { title: "C++ & DSA", desc: "Strong foundation in data structures and algorithms." },
          { title: "Web Development", desc: "Building responsive and modern interfaces." },
          { title: "Continuous Learner", desc: "Always exploring new technologies and tools." },
        ].map((item) => (
          <div key={item.title}>
            <h3 className="font-display font-bold text-xs uppercase tracking-widest mb-2">{item.title}</h3>
            <p className="font-body text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default HeroSection;
