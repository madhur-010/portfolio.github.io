const AboutSection = () => {
  return (
    <section id="about" className="px-6 md:px-16 lg:px-24 py-24">
      <div className="grid md:grid-cols-2 gap-16 items-start">
        <div>
          <h2 className="text-4xl font-display font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
            Crafting
            <br />
            Meaningful
            <br />
            Digital
            <br />
            Experiences
          </h2>
        </div>
        <div className="space-y-6">
          <p className="font-body text-muted-foreground text-base leading-relaxed">
            I am a Computer Science student at MITS Gwalior, passionate about technology, problem-solving, and building impactful digital experiences. I enjoy learning new technologies and applying them to real-world projects.
          </p>
          <p className="font-body text-muted-foreground text-base leading-relaxed">
            With a strong foundation in C++, data structures, and web technologies, I strive to create solutions that are both elegant and effective.
          </p>
        </div>
      </div>

      {/* Education */}
      <div className="mt-20 border-t border-border pt-10">
        <h3 className="font-display font-bold text-xs uppercase tracking-[0.2em] mb-8 text-muted-foreground">🎓 Education</h3>
        <div className="bg-card rounded-2xl p-8 border border-border">
          <h4 className="font-display font-bold text-xl mb-1">B.Tech – Computer Science and Business Systems</h4>
          <p className="font-body text-muted-foreground text-sm mb-3">MITS Gwalior · 2024 – Present</p>
          <p className="font-body text-muted-foreground text-sm leading-relaxed">
            Focused on coding, data structures, and real-world tech applications.
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
