const skills = [
  { name: "C++", level: 90 },
  { name: "Data Structures & Algorithms", level: 85 },
  { name: "Object-Oriented Programming", level: 88 },
  { name: "HTML & CSS", level: 80 },
  { name: "JavaScript", level: 65 },
  { name: "GitHub", level: 75 },
  { name: "Debugging", level: 85 },
  { name: "Analytical Thinking", level: 92 },
];

const SkillsSection = () => {
  return (
    <section id="skills" className="px-6 md:px-16 lg:px-24 py-24 bg-card">
      <div className="grid md:grid-cols-[1fr_2fr] gap-16">
        <div>
          <h2 className="text-4xl md:text-5xl font-display font-black uppercase leading-[0.95] tracking-tight">
            Skills &<br />
            <span className="italic font-normal">Expertise</span>
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {skills.map((skill) => (
            <div key={skill.name} className="space-y-2">
              <div className="flex justify-between items-baseline">
                <span className="font-body font-semibold text-sm">{skill.name}</span>
                <span className="font-display font-bold text-2xl">{skill.level}%</span>
              </div>
              <div className="h-1 bg-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-foreground rounded-full transition-all duration-1000"
                  style={{ width: `${skill.level}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
